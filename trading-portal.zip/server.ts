import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';

// In-memory shared state between web dashboard, trading bot (VS Code), and broker
interface BotGatewayConfig {
  masterExecution: boolean;
  riskPerTradePct: number;
  riskToReward: number;
  maxDailyTrades: number;
  trailingStopActive: boolean;
  autoBreakevenPips: number;
  currency: string;
  updatedAt: string;
  version: number;
}

interface BrokerTelemetry {
  connected: boolean;
  provider: string;
  accountNumber: string;
  server: string;
  currency: string;
  balance: number;
  equity: number;
  floatingPnL: number;
  netProfit: number;
  winRate: number;
  totalTrades: number;
  winningTrades: number;
  losingTrades: number;
  lastPingMs: number;
  lastSyncTime: string;
  lastHeartbeat: string;
  openPositions: Array<{
    ticket: string;
    symbol: string;
    type: 'BUY' | 'SELL';
    lots: number;
    openPrice: number;
    currentPrice: number;
    pnl: number;
    stopLoss?: number;
    takeProfit?: number;
  }>;
}

// Current live state
let activeBotConfig: BotGatewayConfig = {
  masterExecution: true,
  riskPerTradePct: 1.25,
  riskToReward: 2.5,
  maxDailyTrades: 4,
  trailingStopActive: true,
  autoBreakevenPips: 15,
  currency: 'USD',
  updatedAt: new Date().toISOString(),
  version: 1,
};

let activeBrokerTelemetry: BrokerTelemetry = {
  connected: true,
  provider: 'MetaTrader 5',
  accountNumber: '8849102',
  server: 'Deriv-Server-02',
  currency: 'USD',
  balance: 157340.00,
  equity: 159820.50,
  floatingPnL: 2480.50,
  netProfit: 34820.50,
  winRate: 68.4,
  totalTrades: 142,
  winningTrades: 97,
  losingTrades: 45,
  lastPingMs: 14,
  lastSyncTime: new Date().toISOString(),
  lastHeartbeat: new Date().toISOString(),
  openPositions: [
    {
      ticket: '994821',
      symbol: 'EURUSD',
      type: 'BUY',
      lots: 2.5,
      openPrice: 1.08450,
      currentPrice: 1.08620,
      pnl: 425.00,
      stopLoss: 1.08200,
      takeProfit: 1.09100,
    },
    {
      ticket: '994822',
      symbol: 'XAUUSD',
      type: 'BUY',
      lots: 1.0,
      openPrice: 2632.40,
      currentPrice: 2652.95,
      pnl: 2055.50,
      stopLoss: 2615.00,
      takeProfit: 2680.00,
    },
  ],
};

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // CORS middleware for external bots / VS Code scripts
  app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
    if (req.method === 'OPTIONS') {
      return res.sendStatus(200);
    }
    next();
  });

  // 1. Health check
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'ok',
      service: 'Trading Portal Bot & Broker Gateway',
      time: new Date().toISOString(),
      botVersion: activeBotConfig.version,
    });
  });

  // 2. Bot Target Controls: GET (used by VS Code Python Bot, MT5 EA, or Web Portal)
  app.get('/api/bot/config', (req, res) => {
    res.json({
      status: 'success',
      data: activeBotConfig,
    });
  });

  // 3. Bot Target Controls: POST (updates active parameters from Web Dashboard or external bot)
  app.post('/api/bot/config', (req, res) => {
    const {
      masterExecution,
      riskPerTradePct,
      riskToReward,
      maxDailyTrades,
      trailingStopActive,
      autoBreakevenPips,
      currency,
    } = req.body;

    if (typeof masterExecution === 'boolean') activeBotConfig.masterExecution = masterExecution;
    if (typeof riskPerTradePct === 'number') activeBotConfig.riskPerTradePct = riskPerTradePct;
    if (typeof riskToReward === 'number') activeBotConfig.riskToReward = riskToReward;
    if (typeof maxDailyTrades === 'number') activeBotConfig.maxDailyTrades = maxDailyTrades;
    if (typeof trailingStopActive === 'boolean') activeBotConfig.trailingStopActive = trailingStopActive;
    if (typeof autoBreakevenPips === 'number') activeBotConfig.autoBreakevenPips = autoBreakevenPips;
    if (typeof currency === 'string') activeBotConfig.currency = currency;

    activeBotConfig.updatedAt = new Date().toISOString();
    activeBotConfig.version += 1;

    console.log(`[BOT GATEWAY] Updated config v${activeBotConfig.version}: Risk ${activeBotConfig.riskPerTradePct}%, R:R 1:${activeBotConfig.riskToReward}, MaxTrades ${activeBotConfig.maxDailyTrades}, Master: ${activeBotConfig.masterExecution}`);

    res.json({
      status: 'success',
      message: 'Bot parameters updated and active on gateway',
      data: activeBotConfig,
    });
  });

  // 4. Broker Telemetry: GET (returns real account values for the portal)
  app.get('/api/broker/telemetry', (req, res) => {
    res.json({
      status: 'success',
      data: activeBrokerTelemetry,
    });
  });

  // 5. Broker Telemetry: POST (endpoint where VS Code bot or MT5 EA pushes real live broker values)
  app.post('/api/broker/telemetry', (req, res) => {
    const {
      provider,
      accountNumber,
      server,
      currency,
      balance,
      equity,
      floatingPnL,
      netProfit,
      winRate,
      totalTrades,
      winningTrades,
      losingTrades,
      lastPingMs,
      openPositions,
      connected,
    } = req.body;

    if (provider !== undefined) activeBrokerTelemetry.provider = provider;
    if (accountNumber !== undefined) activeBrokerTelemetry.accountNumber = accountNumber;
    if (server !== undefined) activeBrokerTelemetry.server = server;
    if (currency !== undefined) {
      activeBrokerTelemetry.currency = currency.toUpperCase();
      activeBotConfig.currency = currency.toUpperCase();
    }
    if (typeof balance === 'number') activeBrokerTelemetry.balance = balance;
    if (typeof equity === 'number') activeBrokerTelemetry.equity = equity;
    if (typeof floatingPnL === 'number') activeBrokerTelemetry.floatingPnL = floatingPnL;
    if (typeof netProfit === 'number') activeBrokerTelemetry.netProfit = netProfit;
    if (typeof winRate === 'number') activeBrokerTelemetry.winRate = winRate;
    if (typeof totalTrades === 'number') activeBrokerTelemetry.totalTrades = totalTrades;
    if (typeof winningTrades === 'number') activeBrokerTelemetry.winningTrades = winningTrades;
    if (typeof losingTrades === 'number') activeBrokerTelemetry.losingTrades = losingTrades;
    if (typeof lastPingMs === 'number') activeBrokerTelemetry.lastPingMs = lastPingMs;
    if (Array.isArray(openPositions)) activeBrokerTelemetry.openPositions = openPositions;
    if (typeof connected === 'boolean') activeBrokerTelemetry.connected = connected;

    activeBrokerTelemetry.lastSyncTime = new Date().toISOString();
    activeBrokerTelemetry.lastHeartbeat = new Date().toISOString();

    console.log(`[BROKER TELEMETRY] Received live push: Equity ${activeBrokerTelemetry.equity} ${activeBrokerTelemetry.currency}, Balance ${activeBrokerTelemetry.balance}, NetProfit ${activeBrokerTelemetry.netProfit}`);

    res.json({
      status: 'success',
      message: 'Broker telemetry synced successfully',
      data: activeBrokerTelemetry,
      activeBotConfig,
    });
  });

  // 6. Connect / Disconnect simulation or manual trigger
  app.post('/api/broker/connect', (req, res) => {
    activeBrokerTelemetry.connected = true;
    activeBrokerTelemetry.lastHeartbeat = new Date().toISOString();
    res.json({ status: 'success', message: 'Broker connected', data: activeBrokerTelemetry });
  });

  app.post('/api/broker/disconnect', (req, res) => {
    activeBrokerTelemetry.connected = false;
    res.json({ status: 'success', message: 'Broker disconnected', data: activeBrokerTelemetry });
  });

  // Vite middleware for development or static serve in production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true, host: '0.0.0.0' },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 Trading Portal & Bot Gateway running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
